// Estado Inicial do Jogo
let rodada = 1;
let energiaJogador = 3; // Passes disponíveis para o grupo por turno

let reinos = {
    vegetal: 100,
    animal: 100,
    hominal: 100
};

// Lista de eventos baseados na Doutrina Espírita e Ecologia
const eventosCrise = [
    { texto: "Desmatamento detectado! Reino Vegetal perdeu fluido.", alvo: "vegetal", dano: 30 },
    { texto: "O estresse excessivo enfraqueceu o Reino Hominal!", alvo: "hominal", dano: 25 },
    { texto: "Mudanças climáticas abruptas afetaram o Reino Animal.", alvo: "animal", dano: 30 },
    { texto: "Sedentarismo e má alimentação desgastaram o Reino Hominal.", alvo: "hominal", dano: 20 }
];

// Função que atualiza todos os elementos visuais na tela
function atualizarTela() {
    for (let reino in reinos) {
        // Atualiza o texto com a porcentagem
        document.getElementById(`txt-${reino}`).innerText = reinos[reino];
        // Atualiza o tamanho visível da barra de progresso
        document.getElementById(`barra-${reino}`).style.width = reinos[reino] + "%";
        
        let elementoZona = document.getElementById(`zona-${reino}`);
        // Se o Princípio Vital estiver baixo (<= 40%), ativa alerta visual
        if (reinos[reino] <= 40) {
            elementoZona.classList.add('critica');
        } else {
            elementoZona.classList.remove('critica');
        }
    }

    // Atualiza o painel superior de status
    document.getElementById('rodada-atual').innerText = rodada;
    document.getElementById('energia-jogador').innerText = energiaJogador;
}

// CORREÇÃO: Função para doar energia ajustada para não desperdiçar clicks
function doarEnergia(reino) {
    if (energiaJogador > 0) {
        if (reinos[reino] >= 100) {
            adicionarLog("❌ Esse reino já está com o fluido vital máximo!");
            return;
        }
        
        // Se já estiver quase cheio, avisa que vai curar menos mas permite se o jogador quiser
        reinos[reino] = Math.min(100, reinos[reino] + 20);
        energiaJogador--;
        adicionarLog(`✨ Você aplicou um passe fluídico no Reino ${reino.toUpperCase()} (+20%)`);
        atualizarTela();
    } else {
        adicionarLog("❌ Sem energia de doação restante neste turno! Passe a rodada.");
    }
}

// CORREÇÃO: Passar Turno agora valida se as ações foram usadas de forma coerente
function passarTurno() {
    // CORREÇÃO: Impede passar o turno se o jogador não usou as energias dele, 
    // forçando a cooperação e impedindo cliques seguidos sem jogar.
    if (energiaJogador > 0) {
        let confirmar = confirm(`Você ainda tem ${energiaJogador} ponto(s) de energia para doar. Quer mesmo passar o turno sem ajudar os reinos?`);
        if (!confirmar) return; // Cancela a passagem de turno se a criança quiser jogar
    }

    // 1. Consumo biológico natural decorrente da própria vida orgânica (-10%)
    reinos.vegetal = Math.max(0, reinos.vegetal - 10);
    reinos.animal = Math.max(0, reinos.animal - 10);
    reinos.hominal = Math.max(0, reinos.hominal - 10);

    // 2. Sorteia e aplica um evento aleatório de desgaste acelerado (Excessos)
    let crise = eventosCrise[Math.floor(Math.random() * eventosCrise.length)];
    reinos[crise.alvo] = Math.max(0, reinos[crise.alvo] - crise.dano);
    
    adicionarLog(`⚠️ EVENTO: ${crise.texto}`);

    // 3. Verifica condição de fim de jogo (Algum reino zerar o fluido vital)
    if (reinos.vegetal <= 0 || reinos.animal <= 0 || reinos.hominal <= 0) {
        alert(`Fim de Jogo! Um dos reinos esgotou o Princípio Vital na rodada ${rodada}. A matéria desorganizou-se. Cooperem melhor da próxima vez!`);
        reiniciarJogo();
        return;
    }

    // Avança o contador, renova as ações do grupo e atualiza a interface
    rodada++;
    energiaJogador = 3; 
    adicionarLog(`=== RODADA ${rodada} INICIADA ===`);
    atualizarTela();
}

// Adiciona mensagens na caixa de histórico (terminal do jogo)
function adicionarLog(mensagem) {
    const log = document.getElementById('log-eventos');
    log.innerHTML = `> ${mensagem}<br>` + log.innerHTML;
}

// Reseta o estado do jogo para começar de novo
function reiniciarJogo() {
    rodada = 1;
    energiaJogador = 3;
    reinos = { vegetal: 100, animal: 100, hominal: 100 };
    document.getElementById('log-eventos').innerHTML = ">> O jogo foi reiniciado!";
    atualizarTela();
}

// Executa a primeira atualização assim que o arquivo carrega
atualizarTela();
